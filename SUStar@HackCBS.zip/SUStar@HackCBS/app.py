# importing necessary modules
from flask import Flask, render_template, request, session, redirect, url_for
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from sqlalchemy.orm import relationship
from flask_sqlalchemy import SQLAlchemy
from flask_mail import Mail
from werkzeug.utils import secure_filename
import json
import os
from datetime import datetime
import math
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import graph_hackcbs
import pandas as pd



with open('config.json', 'r') as c:
    params = json.load(c)["params"]

local_server = True
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///mydatabase.db'
app.config['UPLOAD_FOLDER'] = params['upload_location']
app.secret_key = 'super-secret-key'
login_manager = LoginManager()
ALLOWED_EXTENSIONS = {'csv'}
login_manager.login_view = "login"
login_manager.init_app(app)
db = SQLAlchemy(app)


class userdata(UserMixin, db.Model):
    user_id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(255), nullable = False)
    password = db.Column(db.String(255), nullable = False)
    file_name = db.Column(db.String(1000), nullable = True)
    uploaded_files = db.relationship('UploadedFile', backref='user', lazy=True)

    def get_id(self):
        """Returns user Id"""
        return str(self.user_id)
    
    def get_username(self):
        """Returns user Id"""
        return str(self.username)


class UploadedFile(db.Model):
    __tablename__ = 'uploaded_files'
    id = db.Column(db.Integer, primary_key=True)
    file_name = db.Column(db.String(100), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('userdata.user_id'))

with app.app_context():
    db.create_all()

@app.route("/")
def home():
    return render_template("index.html")

@app.route('/analyse', methods=['GET', 'POST'])
def analyse():
    if current_user.is_authenticated:
        user = userdata.query.filter_by(user_id=current_user.user_id).first()
        return render_template('analyse.html', file_name=user)
    else:
        return render_template('login.html')

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        user = userdata.query.filter_by(username=username, password=password).first()
        if user:
            login_user(user)
            return render_template("analyse.html", file_name=user)
        else:
            return "Login failed. Check your username and password."
    return render_template("login.html")


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check if the username is already taken
        existing_user = userdata.query.filter_by(username=username).first()
        if existing_user:
            return "Username already exists. Please choose another one."
        # Create a new user
        new_user = userdata(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        return render_template("analyse.html", params=params, file_name=existing_user)
    return render_template('signup.html')


@app.route('/upload', methods=['POST'])
@login_required
def upload_file():
    if 'file' not in request.files:
        return "No file part"

    file = request.files['file']

    if file.filename == '':
        return "No selected file"

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        current_user.file_name = filename
        db.session.commit()
        return redirect(url_for('analyse'))
    return "Invalid file format. Allowed extensions: .csv"


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


@login_manager.user_loader
def load_user(user_id):
    return userdata.query.get(int(user_id))
login_manager.init_app(app)


@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for("login"))


@app.route('/send', methods=['GET', 'POST'])
def send(): 
    if request.method == 'POST':
        username = current_user.get_username()
        selected_option = request.form.get('selected')
        user = userdata.query.filter_by().first()
        file = params['upload_location']+'\\' + str(user.file_name)
        graph_hackcbs.main(selected_option, file)
        user = userdata.query.filter_by(user_id=current_user.user_id).first()
        return render_template('analyse.html', file_name=user)
    else:
        return render_template('signup.html')


if __name__ == '__main__':
    app.run(debug=True)
